/*
 * PITA_Funct.h
 *
 *  Created on: Jan 4, 2017
 *      Author: tevin
 */

#ifndef PITA_FUNCT_H_
#define PITA_FUNCT_H_

extern int game_field[49];
extern int tunnel_map[49];
extern int grid_orientation;

////////////////////////////////////////////////
// Functions								  //
////////////////////////////////////////////////

//---------------------------------------------------------------------------
// hardware_init()
//
// inits hardware being used
//---------------------------------------------------------------------------
void hardware_init(void);


int command_line(void);
void UARTNextLine(void);
void delay_m(uint32_t time);
void step_off_R(void);

//---------------------------------------------------------------------------
// uSensor()
//
// Determine distance between ultrasnoic sensor and nearest obstacle (up to 4m)
//---------------------------------------------------------------------------
double uSensor(void);


uint32_t ir_sensor(void);

//---------------------------------------------------------------------------
// motor_move()
//
// rotate the stepper motors a certain amount of steps
//---------------------------------------------------------------------------
void motor_move(uint32_t steps,char continuous);

void motor_rotate(int degrees,char dir);
//---------------------------------------------------------------------------
// motor_rotateRight_90()
//
// rotate the robot to the right 90 degrees
//---------------------------------------------------------------------------
void motor_rotateRight_90(void);

//---------------------------------------------------------------------------
// motor_rotateLeft_90()
//
// rotate the robot to the left 90 degrees
//---------------------------------------------------------------------------
void motor_rotateLeft_90(void);
int motor_ramp(int currStep,int maxSteps,int finalDelay,char continuous, int currDelay);
void alignment_fix(int lineAngle);
void center_robot(int x_dist);
void step_off_R(void);
void move_forward_1ft(void);
void move(int inches,char dir,char continuous);
void wheel_correction(int angle);
void navigate_snake(void);
int avoid_obstacle(int currentGrid);
void map_tunnels(void);
void timer_wait(int microseconds);
void led_control(void);
void cache_align(void);
uint32_t capacitive_sensor(void);
int identify_tunnel(char paper,int grid);
void rotate_arm(int degrees);
void move_arm(char dir);
void arm_grip(char open);
void remove_cache(int degrees);
int receive_pi_command(void);
void send_pi_command(uint16_t command);
int detect_line(void);
int getData(void);
uint32_t locate_cache(void);
uint8_t find_pips(void);
void move_forward(void);
void brake(void);
void ramp_up(void);
int inc_steps(void);
void I2CSend(uint8_t slave_addr, uint8_t num_of_args, ...);
uint32_t I2CReceive(uint32_t slave_addr, uint8_t reg);
void robot_adjustRight(float degrees);
void robot_adjustLeft(float degrees);
void robot_adjustEnd(void);
void wire_follow(void);
void configMPU6050(void);
void read6050(void);


#endif /* PITA_FUNCT_H_ */
