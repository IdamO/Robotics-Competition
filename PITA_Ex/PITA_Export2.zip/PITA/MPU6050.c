/*
 * MPU6050.c
 *
 *  Created on: Mar 18, 2017
 *      Author: tevin
 */




