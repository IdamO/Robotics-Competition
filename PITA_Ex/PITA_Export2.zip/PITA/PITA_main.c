//----------------------------------------
// BIOS header files
//----------------------------------------
#include <xdc/std.h>  						//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 				//mandatory - if you call APIs like BIOS_start()
#include <xdc/runtime/Log.h>				//needed for any Log_info() call
#include <xdc/cfg/global.h> 				//header file for statically defined objects/handles


//------------------------------------------
// TivaWare Header Files
//------------------------------------------
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "inc/hw_ints.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"
#include "driverlib/uart.h"
#include "driverlib/adc.h"
#include "driverlib/pwm.h"
#include "PITA_Funct.h"
#include "MPU6500.h"
#include "utils/uartstdio.h"
#include "Time.h"
#include "IMU.h"
#include "I2C.h"
#include "driverlib/systick.h"
#include "EEPROM.h"
#include "MPU6500.h"
#include "PID.h"
#include "Time.h"

//----------------------------------------
// Macros
//----------------------------------------
//Start Button
#define START_BASE			GPIO_PORTD_BASE
#define START_PIN			GPIO_PIN_0

//----------------------------------------
// Prototypes
//----------------------------------------
void PITA_standby(void);
void game_nav(void);
void movement(void);
char obstacle_check(int currentGrid);
int tunnel_check(int currentGrid);
char cache_removal(void);
char die_check(void);
void return_to_start(void);
int grid_change(int grid,char* grid_orientation);
void game_mode(void);
void incSteps(void);
void checkGyro(void);
void align_adjust(void);

uint8_t state = 0x00;
uint8_t prevState = 0x00;
char moving = 0;
char checkTunnels = 0;
char cache_detected = 0;
uint8_t distToCache = 0;
int steps = 0;;
int game_grid = 0;
char grid_orient = 0;
char moved_from_edge = 1;
extern mpu6500_t mpu6500;
angle_t angle; // Struct used to store angles
sensor_t mag = { .data = { 1.0f, 0.0f, 0.0f } }; // If no magnetometer is used, then just use a vector with a x-component only
float yaw = -1;
//float angle = 0;
char gyroAct = 0;
int count = 0;
char adjusting = 0;
char adjustOcc = 0;
char adjDelay = 0;
//---------------------------------------------------------------------------
// main()
//---------------------------------------------------------------------------
void main(void)
{
   hardware_init();							// init hardware via Xware
   BIOS_start();

}

 // PITA_standby()
// wait for the start button to be pushed
// when start button is pushed trigger interrupt and begin movement
//---------------------------------------------------------------------------
void PITA_standby()
{
	char test_mode = 0;
	if (test_mode){
		//UARTprintf("\nSystem is in test mode. Starting command line.\n");
		//movement();
		while (1) {
		   test_mode = command_line();
		   if (test_mode==0){
			   delay_m(6700000*8);
			   movement();
			   moving = 1;
		   }
		}
	}
	else {
		// wait for the start button to be pushed
//		while(GPIOPinRead(START_BASE,START_PIN)==0x00){
//		}
		//delay_m(6700000*8);
		// post interrupt to begin game
		//Swi_post(Field_Navigation);
		game_mode();
	}
}

void game_mode(void) {

	if (state==0x00) {
		// wait for start button to be pushed
		delay_m(6700000*8);
		state = 0x01;
		game_grid = 42;
		// get initial yaw
		if (dataReadyMPU6500()) {
			uint32_t now = micros();
			static uint32_t timer = 0; // Used to keep track of the time
			float dt = (float)(now - timer) / 1e6f; // Convert to seconds
			//UARTprintf("%d\n", now - timer);
			timer = now;

			// Read IMU
			getMPU6500Data(&mpu6500); // Get accelerometer and gyroscope values
			getAngles(&mpu6500, &mag, &angle, dt); // Calculate pitch, roll and yaw

			UARTprintf("gyro: %d %d %d\n", (int)mpu6500.gyro.data[0],(int)mpu6500.gyro.data[1],(int)mpu6500.gyro.data[2]);
			UARTprintf("gyroRate: %d %d %d\n", (int)mpu6500.gyroRate.data[0],(int)mpu6500.gyroRate.data[1],(int)mpu6500.gyroRate.data[2]);
			UARTprintf("%d\t%d\t%d\n", (int16_t)angle.axis.roll, (int16_t)angle.axis.pitch, (int16_t)angle.axis.yaw);

			yaw = angle.axis.yaw;
			resetPIDRollPitchYaw();
		}
		gyroAct = 1;
	}
	else if (state==0x01) { // move forward state
		// movement
		if (moving==0) {
			move_forward();
			ramp_up();
			steps = steps + 400;
			moving = 1;
			checkTunnels = 1;
		}
		else {
			//move_forward();
		}
		// when you reach an edge
		if (game_grid==6) {
			moving = 0;
			state = 0x04;
			brake();
		}
		else if ((game_grid<7 || game_grid>42) && moved_from_edge==1) {
			brake();
			moving = 0;
			state = 0x02;	// edge case state
			moved_from_edge = 0;
			gyroAct = 0;
			if (game_grid < 7) {
				yaw = yaw + 180;
				if (yaw > 359) {
					yaw = yaw-359;
				}
			}
			else if (game_grid>42) {
				yaw = yaw-180;
				if (yaw < 0) {
					yaw = 359 + yaw;
				}
			}
		}
	}
	else if (state==0x02) { // edge case
		if (game_grid<7) {
			motor_rotateRight_90();
			move_forward_1ft();
			game_grid++;
			motor_rotateRight_90();
			state = 0x01;
			grid_orient = 1;
			gyroAct = 1;
		}
		else {
			motor_rotateLeft_90();
			move_forward_1ft();
			game_grid++;
			motor_rotateLeft_90();
			state = 0x01;
			grid_orient = 0;
			gyroAct = 1;
		}
	}
	else if (state==0x03) { // cache (at endpoint) state
		moving = 0;
		cache_removal();
		state = prevState;
	}
	else if (state==0x04) {
		//return_to_start();
		//state = 0x00;
	}

}

void movement(void) {
	move_forward();
	ramp_up();
}

void game_nav()
{
	int grid = 42;
	int tunnel;
	grid_orientation = 0;
	while (grid!=6){
		move_forward_1ft();
		if (grid_orientation==0){
			grid = grid-7;
		}
		else {
			grid = grid+7;
		}
		UARTprintf("%d\n",grid);
		game_field[grid] = tunnel_check(grid);

		// move to next column if at top or bottom edge
		if (grid<7 && grid!=6) {
			UARTprintf("Here\n");
			motor_rotateRight_90();
			move_forward_1ft();
			grid++;
			motor_rotateRight_90();
			game_field[grid] = tunnel_check(grid);
			grid_orientation = 1;
		}
		else if (grid>41){
			UARTprintf("Here2\n");
			motor_rotateLeft_90();
			move_forward_1ft();
			grid++;
			motor_rotateLeft_90();
			game_field[grid] = tunnel_check(grid);
			grid_orientation = 0;
		}

	}
	//return_to_start();
}

int grid_change(int grid,char* grid_orientation)
{
	int new_grid = grid;
	if (*grid_orientation==0) {
		new_grid = new_grid-7;
	}
	else if (*grid_orientation==1) {
		new_grid = new_grid+7;
	}
	return new_grid;
}

void return_to_start()
{
	int grid = 6;
	motor_rotateLeft_90();
	while (grid != 42){
		if (grid==0){
			motor_rotateLeft_90();
		}
		else if (grid<7){
			obstacle_check(grid);
			move_forward_1ft();
			grid--;
		}
		else if (grid%7==0){
			obstacle_check(grid);
			move_forward_1ft();
			grid = grid+7;
		}
	}

}

//---------------------------------------------------------------------------
// obstacle_check()
//
// poll data on ir sensor
//---------------------------------------------------------------------------
char obstacle_check(int currentGrid)
{
	uint32_t distData = ir_sensor();
	if (distData > 700){
		// Turn on the LED
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, 4);
		avoid_obstacle(currentGrid);
		return 1;
	}
	return 0;
}

//---------------------------------------------------------------------------
// tunnel_check()
//
// use appropriate sensor to detect if there is a tunnel at the location
//---------------------------------------------------------------------------
int tunnel_check(int currentGrid)
{
	if (checkTunnels==1) {
		int tunnel = identify_tunnel(0,game_grid);
		game_field[game_grid] = tunnel;
		UARTprintf("%d %d\n",game_grid,tunnel);
		return tunnel;
	}
}

//---------------------------------------------------------------------------
// cache_check()
//
// call to raspberry pi to check for cache
//---------------------------------------------------------------------------
char cache_removal()
{
	int degrees;
	int location_x,location_y;
	// locate cache
	send_pi_command(0x02);
	degrees = getData();
	location_x = getData();
	location_y = getData();

	// align gripper with cache
	// remove the lid
	if (die_check()){
		//call to pi to perform the die functions
		//pi will display on the 7-seg
	}
	return 0;
}

//---------------------------------------------------------------------------
// die_check()
//
// call to raspberry pi to check for die
//---------------------------------------------------------------------------
char die_check()
{
	send_pi_command(0x03);
	return 0;
}

void incSteps() {
	if (moving!=0) {
		steps++;
		if (steps>=2480) {
			steps = 0;
			game_grid = grid_change(game_grid,&grid_orient);
			moved_from_edge = 1;
			//UARTprintf("%d\n",game_grid);
			if (game_grid < 7 || game_grid > 41) {
				moving = 0;
				brake();
			}
		}
		PWMGenIntClear(PWM0_BASE,PWM_GEN_3,PWM_INT_CNT_ZERO);
	}
}

void align_adjust() {
	if (moving!=0 && adjusting==0) {
		adjusting = 1;
		int checkVal;

		UARTprintf("%d\n",(int16_t)angle.axis.yaw);
		if (grid_orientation==0 && ((int16_t)angle.axis.yaw < 358 && (int16_t)angle.axis.yaw > 1)) {
			adjustOcc = 1;
			if (angle.axis.yaw<180) {
				robot_adjustLeft(0);
			}
			else {
				robot_adjustRight(0);
			}
			//UARTprintf("%d\n",(int16_t)angle.axis.yaw);
		}
		else if (grid_orientation==1 && ((int16_t)angle.axis.yaw < yaw-1 && (int16_t)angle.axis.yaw > yaw+1)) {
			if (angle.axis.yaw>(int16_t)yaw) {
				robot_adjustLeft(0);
			}
			else {
				robot_adjustRight(0);
			}
		}
		else {
			robot_adjustEnd();
		}
		adjusting = 0;
	}
}

void checkGyro() {
	if (gyroAct==1) {
		gyroAct=0;
		if (dataReadyMPU6500()) {
			uint32_t now = micros();
			static uint32_t timer = 0; // Used to keep track of the time
			float dt = (float)(now - timer) / 1e6f; // Convert to seconds
			//UARTprintf("%d\n", now - timer);
			timer = now;

			// Read IMU
			getMPU6500Data(&mpu6500); // Get accelerometer and gyroscope values
			getAngles(&mpu6500, &mag, &angle, dt); // Calculate pitch, roll and yaw

//			UARTprintf("gyro: %d %d %d\n", (int)mpu6500.gyro.data[0],(int)mpu6500.gyro.data[1],(int)mpu6500.gyro.data[2]);
//			UARTprintf("gyroRate: %d %d %d\n", (int)mpu6500.gyroRate.data[0],(int)mpu6500.gyroRate.data[1],(int)mpu6500.gyroRate.data[2]);
//			UARTprintf("%d\t%d\t%d\n", (int16_t)angle.axis.roll, (int16_t)angle.axis.pitch, (int16_t)angle.axis.yaw);

			if (yaw == -1) {
				yaw = angle.axis.yaw;
			}
			resetPIDRollPitchYaw();
//			UARTprintf("%d\t%d\t%d\n", (int16_t)angle.axis.roll, (int16_t)angle.axis.pitch, (int16_t)angle.axis.yaw);
		}
		gyroAct=1;
	}
}

